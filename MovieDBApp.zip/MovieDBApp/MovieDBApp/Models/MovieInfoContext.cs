﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MovieDBApp.Models
{
    public class MovieInfoContext : DbContext
    {
        //Constructor
        public MovieInfoContext (DbContextOptions<MovieInfoContext> options) : base (options)
        {
            //Leave Blank for Now
        }
        public DbSet<MovieFormResponse> MovieInformation { get; set; }

        protected override void OnModelCreating(ModelBuilder mV)
        {
            mV.Entity<MovieFormResponse>().HasData(
                
                new MovieFormResponse
                {
                    MovieId = 1,
                    MovieTitle = "The Lake House",
                    MovieCategory = "Drama",
                    MovieYear = 2006,
                    MovieDirector = "Alejandro Agresti",
                    MovieRating = "PG",
                    Edited = false,
                    LentTo = "",
                    Notes = ""
                }
            );
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Threading.Tasks;

namespace MovieDBApp.Models
{
    public class MovieFormResponse
    {
        [Key]
        [Required]
        public int MovieId { get; set; }
        [Required]
        public string MovieTitle { get; set; }
        [Required]
        public string MovieCategory { get; set; }
        [Required]
        public int MovieYear { get; set; }
        [Required]
        public string MovieDirector { get; set; }
        [Required]
        public string MovieRating { get; set; }
        public bool Edited { get; set; }
        public string LentTo { get; set; }
        public string Notes { get; set; }
    }
}

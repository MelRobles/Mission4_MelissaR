﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MovieDBApp.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace MovieDBApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private MovieInfoContext _movieContext { get; set; }
        //constructor
        public HomeController(ILogger<HomeController> logger, MovieInfoContext someName)
        {
            _logger = logger;
            _movieContext = someName;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult MForm()
        {
            return View();
        }

        [HttpPost]
        public IActionResult MForm(MovieFormResponse MovieRes)
        {
            _movieContext.Add(MovieRes);
            _movieContext.SaveChanges();
            return View("Comfirmation", MovieRes);
        }

    }
}
